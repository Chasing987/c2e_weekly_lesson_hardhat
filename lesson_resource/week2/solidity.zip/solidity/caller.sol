// SPDX-License-Identifier: MIT
pragma solidity ^0.8.0;

contract caller{
   address public constant calledaddress = 0x9d83e140330758a8fFD07F8Bd73e86ebcA8a5692;
   function callering() public {
        (bool success, bytes memory result) =calledaddress.call(abi.encodeWithSignature("count()"));
    
        if(!success){
            revert("error");
    }
   }
    function caller_error() public {
        (bool success,bytes memory result) = calledaddress.call(abi.encodeWithSignature("count")); //call一个不存在的函数
        if(!success){
            revert("error");
        }
    }
}