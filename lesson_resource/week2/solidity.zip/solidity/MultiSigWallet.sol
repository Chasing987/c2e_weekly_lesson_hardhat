// SPDX-License-Identifier: MIT
pragma solidity ^0.8.0;

contract MultiSigWallet {
    // 事件
    event TransactionSubmitted(
        uint256 indexed transactionId,
        address indexed sender,
        address indexed to,
        uint256 value,
        bytes data
    );
    event TransactionConfirmed(uint256 indexed transactionId, address indexed confirmBy);
    event TransactionExecuted(uint256 indexed transactionId, address indexed executor);
    event TransactionRevoked(uint256 indexed transactionId, address indexed revoker);
    event RequiredConfirmationsChanged(uint256 oldRequired, uint256 newRequired);
    event OwnerAdded(address indexed newOwner);
    event OwnerRemoved(address indexed removedOwner);

    // 状态变量
    address[] public owners;
    mapping(address => bool) public isOwner;
    uint256 public requiredConfirmations;

    struct Transaction {
        address to;
        uint256 value;
        bytes data;
        bool executed;
    }

    Transaction[] public transactions;
    mapping(uint256 => mapping(address => bool)) public confirmed;

    // 修饰器
    modifier onlyOwner() {
        require(isOwner[msg.sender], "Not an owner");
        _;
    }

    modifier transactionExists(uint256 _transactionId) {
        require(_transactionId < transactions.length, "Transaction does not exist");
        _;
    }

    modifier notExecuted(uint256 _transactionId) {
        require(!transactions[_transactionId].executed, "Transaction already executed");
        _;
    }

    modifier notConfirmed(uint256 _transactionId) {
        require(!confirmed[_transactionId][msg.sender], "Transaction already confirmed");
        _;
    }

    // 初始化
    constructor(address[] memory _owners, uint256 _requiredConfirmations) {
        require(_owners.length > 0, "Owners required");
        require(
            _requiredConfirmations > 0 && _requiredConfirmations <= _owners.length,
            "Invalid required confirmations"
        );

        for (uint256 i = 0; i < _owners.length; i++) {
            address owner = _owners[i];
            require(owner != address(0), "Invalid owner");
            require(!isOwner[owner], "Owner not unique");
            isOwner[owner] = true;
            owners.push(owner);
        }
        requiredConfirmations = _requiredConfirmations;
    }

    // 提交交易
    function submitTransaction(
        address _to,
        uint256 _value,
        bytes memory _data
    ) external onlyOwner {
        uint256 transactionId = transactions.length;
        transactions.push(
            Transaction({
                to: _to,
                value: _value,
                data: _data,
                executed: false
            })
        );
        emit TransactionSubmitted(transactionId, msg.sender, _to, _value, _data);
    }

    // 确认交易
    function confirmTransaction(uint256 _transactionId)
        external
        onlyOwner
        transactionExists(_transactionId)
        notExecuted(_transactionId)
        notConfirmed(_transactionId)
    {
        confirmed[_transactionId][msg.sender] = true;
        emit TransactionConfirmed(_transactionId, msg.sender);
    }

    // 执行交易
    function executeTransaction(uint256 _transactionId)
        external
        onlyOwner
        transactionExists(_transactionId)
        notExecuted(_transactionId)
    {
        Transaction storage transaction = transactions[_transactionId];
        uint256 confirmationsCount = 0;

        for (uint256 i = 0; i < owners.length; i++) {
            if (confirmed[_transactionId][owners[i]]) {
                confirmationsCount++;
            }
        }

        require(
            confirmationsCount >= requiredConfirmations,
            "Insufficient confirmations"
        );

        transaction.executed = true;
        (bool success, ) = transaction.to.call{value: transaction.value}(
            transaction.data
        );
        require(success, "Transaction failed");

        emit TransactionExecuted(_transactionId, msg.sender);
    }

    // 撤销确认
    function revokeConfirmation(uint256 _transactionId)
        external
        onlyOwner
        transactionExists(_transactionId)
        notExecuted(_transactionId)
    {
        require(confirmed[_transactionId][msg.sender], "Transaction not confirmed");
        confirmed[_transactionId][msg.sender] = false;
        emit TransactionRevoked(_transactionId, msg.sender);
    }

    // 修改最小确认数
    function changeRequiredConfirmations(uint256 _newRequiredConfirmations)
        external
        onlyOwner
    {
        require(
            _newRequiredConfirmations > 0 &&
                _newRequiredConfirmations <= owners.length,
            "Invalid required confirmations"
        );
        emit RequiredConfirmationsChanged(
            requiredConfirmations,
            _newRequiredConfirmations
        );
        requiredConfirmations = _newRequiredConfirmations;
    }

    // 添加成员
    function addOwner(address _newOwner) external onlyOwner {
        require(!isOwner[_newOwner], "Already an owner");
        require(_newOwner != address(0), "Invalid owner");
        isOwner[_newOwner] = true;
        owners.push(_newOwner);
        emit OwnerAdded(_newOwner);
    }

    // 移除成员
    function removeOwner(address _ownerToRemove) external onlyOwner {
        require(isOwner[_ownerToRemove], "Not an owner");
        require(_ownerToRemove != msg.sender, "Cannot remove yourself");
        require(
            owners.length > requiredConfirmations,
            "Cannot remove owner: required confirmations too high"
        );

        for (uint256 i = 0; i < owners.length; i++) {
            if (owners[i] == _ownerToRemove) {
                owners[i] = owners[owners.length - 1];
                owners.pop();
                delete isOwner[_ownerToRemove];
                break;
            }
        }
        emit OwnerRemoved(_ownerToRemove);
    }

    // 接收ETH
    receive() external payable {}
}