// SPDX-License-Identifier: MIT
pragma solidity ^0.8.0;

contract called {
    uint8 public num1 = 1;
    function count() public returns (uint8) {
        num1++;
        return num1;
    }
}